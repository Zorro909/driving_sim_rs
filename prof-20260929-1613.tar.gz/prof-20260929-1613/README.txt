altd GPU profiling run 2026-09-29T16:13:23+02:00
repo: /home/zorro/git/AILearnsToDrive/driving_sim_rs  git: 39bb745 22 modified files
library: /home/zorro/git/AILearnsToDrive/driving_sim_rs/target/gpu/libaltd_gpu.so
checkpoint: /tmp/altd-gpu-ckpt
sizes: 8192 32768 262144  rayon threads: 8

9dcb172940a8e88d14f48a9ae2355e93ce9ef8ebdf9e131f28465abd480f903d  /home/zorro/git/AILearnsToDrive/driving_sim_rs/target/gpu/libaltd_gpu.so
level 1: ALTD_GPU_PROFILE=1 prints GPU seconds per phase and per 600 ticks; graphs are disabled in this mode
phases_8192_elim0: rc=0 seconds=3 :: env ALTD_GPU_BENCH_CARS=8192 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_PROFILE=1 target/release/examples/gpu_check benchfixed
phases_8192_elim1: rc=0 seconds=1 :: env ALTD_GPU_BENCH_CARS=8192 ALTD_GPU_BENCH_ELIMINATE=1 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_PROFILE=1 target/release/examples/gpu_check benchfixed
phases_32768_elim0: rc=0 seconds=7 :: env ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_PROFILE=1 target/release/examples/gpu_check benchfixed
phases_32768_elim1: rc=0 seconds=2 :: env ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=1 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_PROFILE=1 target/release/examples/gpu_check benchfixed
phases_262144_elim0: rc=0 seconds=48 :: env ALTD_GPU_BENCH_CARS=262144 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_PROFILE=1 target/release/examples/gpu_check benchfixed
phases_262144_elim1: rc=0 seconds=15 :: env ALTD_GPU_BENCH_CARS=262144 ALTD_GPU_BENCH_ELIMINATE=1 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_PROFILE=1 target/release/examples/gpu_check benchfixed
phases_8192_elim1_fused: rc=0 seconds=1 :: env ALTD_GPU_BENCH_CARS=8192 ALTD_GPU_BENCH_ELIMINATE=1 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_PROFILE=1 ALTD_GPU_SPLIT=0 target/release/examples/gpu_check benchfixed
phases_32768_elim1_fused: rc=0 seconds=2 :: env ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=1 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_PROFILE=1 ALTD_GPU_SPLIT=0 target/release/examples/gpu_check benchfixed
level 1b: production-mode wall clock, split vs fused step (graph on, no profiling)
wall_split1_8192_elim0: rc=0 seconds=7 :: env ALTD_GPU_SPLIT=1 ALTD_GPU_BENCH_CARS=8192 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=1 ALTD_GPU_BENCH_SAMPLES=2 target/release/examples/gpu_check benchfixed
wall_split1_8192_elim1: rc=0 seconds=2 :: env ALTD_GPU_SPLIT=1 ALTD_GPU_BENCH_CARS=8192 ALTD_GPU_BENCH_ELIMINATE=1 ALTD_GPU_BENCH_WARMUPS=1 ALTD_GPU_BENCH_SAMPLES=2 target/release/examples/gpu_check benchfixed
wall_split1_32768_elim0: rc=0 seconds=19 :: env ALTD_GPU_SPLIT=1 ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=1 ALTD_GPU_BENCH_SAMPLES=2 target/release/examples/gpu_check benchfixed
wall_split1_32768_elim1: rc=0 seconds=5 :: env ALTD_GPU_SPLIT=1 ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=1 ALTD_GPU_BENCH_WARMUPS=1 ALTD_GPU_BENCH_SAMPLES=2 target/release/examples/gpu_check benchfixed
wall_split0_8192_elim0: rc=0 seconds=7 :: env ALTD_GPU_SPLIT=0 ALTD_GPU_BENCH_CARS=8192 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=1 ALTD_GPU_BENCH_SAMPLES=2 target/release/examples/gpu_check benchfixed
wall_split0_8192_elim1: rc=0 seconds=1 :: env ALTD_GPU_SPLIT=0 ALTD_GPU_BENCH_CARS=8192 ALTD_GPU_BENCH_ELIMINATE=1 ALTD_GPU_BENCH_WARMUPS=1 ALTD_GPU_BENCH_SAMPLES=2 target/release/examples/gpu_check benchfixed
wall_split0_32768_elim0: rc=0 seconds=19 :: env ALTD_GPU_SPLIT=0 ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=1 ALTD_GPU_BENCH_SAMPLES=2 target/release/examples/gpu_check benchfixed
wall_split0_32768_elim1: rc=0 seconds=5 :: env ALTD_GPU_SPLIT=0 ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=1 ALTD_GPU_BENCH_WARMUPS=1 ALTD_GPU_BENCH_SAMPLES=2 target/release/examples/gpu_check benchfixed
level 5: forward seconds of a 32K full run per variant. diag1 = no activation, diag2 = no weight traffic, diag3 = activation only, branchy = scalar tanh
forward_current: rc=0 seconds=7 :: env ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_LIB=/home/zorro/git/AILearnsToDrive/driving_sim_rs/target/gpu/libaltd_gpu.so ALTD_GPU_PROFILE=1 target/release/examples/gpu_check benchfixed
build_branchy: rc=0 seconds=4 :: hipcc -O3 -ffp-contract=off --offload-arch=gfx1100 -fPIC -shared -std=c++20 -fhip-fp32-correctly-rounded-divide-sqrt -DALTD_TANH_BRANCHY -o /home/zorro/git/AILearnsToDrive/driving_sim_rs/target/gpu/libaltd_gpu_branchy.so gpu/sim/altd_gpu.hip -lamdhip64
forward_branchy: rc=0 seconds=7 :: env ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_LIB=/home/zorro/git/AILearnsToDrive/driving_sim_rs/target/gpu/libaltd_gpu_branchy.so ALTD_GPU_PROFILE=1 target/release/examples/gpu_check benchfixed
build_diag1: rc=0 seconds=4 :: hipcc -O3 -ffp-contract=off --offload-arch=gfx1100 -fPIC -shared -std=c++20 -fhip-fp32-correctly-rounded-divide-sqrt -DALTD_FORWARD_DIAG=1 -o /home/zorro/git/AILearnsToDrive/driving_sim_rs/target/gpu/libaltd_gpu_diag1.so gpu/sim/altd_gpu.hip -lamdhip64
forward_diag1: rc=0 seconds=6 :: env ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_LIB=/home/zorro/git/AILearnsToDrive/driving_sim_rs/target/gpu/libaltd_gpu_diag1.so ALTD_GPU_PROFILE=1 target/release/examples/gpu_check benchfixed
build_diag2: rc=0 seconds=4 :: hipcc -O3 -ffp-contract=off --offload-arch=gfx1100 -fPIC -shared -std=c++20 -fhip-fp32-correctly-rounded-divide-sqrt -DALTD_FORWARD_DIAG=2 -o /home/zorro/git/AILearnsToDrive/driving_sim_rs/target/gpu/libaltd_gpu_diag2.so gpu/sim/altd_gpu.hip -lamdhip64
forward_diag2: rc=0 seconds=7 :: env ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_LIB=/home/zorro/git/AILearnsToDrive/driving_sim_rs/target/gpu/libaltd_gpu_diag2.so ALTD_GPU_PROFILE=1 target/release/examples/gpu_check benchfixed
build_diag3: rc=0 seconds=4 :: hipcc -O3 -ffp-contract=off --offload-arch=gfx1100 -fPIC -shared -std=c++20 -fhip-fp32-correctly-rounded-divide-sqrt -DALTD_FORWARD_DIAG=3 -o /home/zorro/git/AILearnsToDrive/driving_sim_rs/target/gpu/libaltd_gpu_diag3.so gpu/sim/altd_gpu.hip -lamdhip64
forward_diag3: rc=0 seconds=6 :: env ALTD_GPU_BENCH_CARS=32768 ALTD_GPU_BENCH_ELIMINATE=0 ALTD_GPU_BENCH_WARMUPS=0 ALTD_GPU_BENCH_SAMPLES=1 ALTD_GPU_LIB=/home/zorro/git/AILearnsToDrive/driving_sim_rs/target/gpu/libaltd_gpu_diag3.so ALTD_GPU_PROFILE=1 target/release/examples/gpu_check benchfixed
